package com.example.projectdogs;

public class reportForm {
    private String TypeDog, WhenDog,WhereDog;

    public reportForm() {
    }

    public String getTypeDog() {
        return TypeDog;
    }

    public void setTypeDog(String typeDog) {
        TypeDog = typeDog;
    }

    public String getWhenDog() {
        return WhenDog;
    }

    public void setWhenDog(String whenDog) {
        WhenDog = whenDog;
    }

    public String getWhereDog() {
        return WhereDog;
    }

    public void setWhereDog(String whereDog) {
        WhereDog = whereDog;
    }
}
